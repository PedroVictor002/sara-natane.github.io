# BELOS FIOS
- `npm install` · `npm run dev` (teste) · `npm run build` (gera /dist para publicar em Netlify, Vercel ou Cloudflare Pages)
- Textos, serviços e galeria: `src/data.js`. Arquivos de antes/depois e vídeos: `public/results/`.
