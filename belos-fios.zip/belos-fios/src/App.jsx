import { useEffect, useRef, useState } from 'react'
import { Menu, X, MessageCircle, Instagram, MapPin, Sparkles, Heart, Droplets, Gem, Gift } from 'lucide-react'
import { services, results, wa, PHONE_LABEL, INSTAGRAM, INSTAGRAM_URL } from './data.js'

const icons = { Sparkles, Heart, Droplets, Gem }

function Reveal({ children, className = '' }) {
  const ref = useRef(null)
  const [on, setOn] = useState(false)
  useEffect(() => {
    const o = new IntersectionObserver(([e]) => { if (e.isIntersecting) { setOn(true); o.disconnect() } }, { threshold: 0.12 })
    o.observe(ref.current)
    return () => o.disconnect()
  }, [])
  return <div ref={ref} className={`reveal ${on ? 'in' : ''} ${className}`}>{children}</div>
}

const Btn = ({ href, children, variant = 'gold', ...p }) => (
  <a className={`btn ${variant}`} href={href} target="_blank" rel="noopener noreferrer" {...p}>{children}</a>
)

const links = [['inicio', 'Início'], ['sobre', 'Sobre'], ['servicos', 'Serviços'], ['resultados', 'Resultados'], ['contato', 'Contato']]

function Header() {
  const [open, setOpen] = useState(false)
  const [solid, setSolid] = useState(false)
  useEffect(() => {
    const f = () => setSolid(window.scrollY > 30)
    f(); window.addEventListener('scroll', f, { passive: true })
    return () => window.removeEventListener('scroll', f)
  }, [])
  return (
    <header className={`header ${solid || open ? 'solid' : ''}`}>
      <a href="#inicio" className="logo">BELOS <span>FIOS</span></a>
      <nav className={open ? 'open' : ''}>
        {links.map(([id, l]) => <a key={id} href={`#${id}`} onClick={() => setOpen(false)}>{l}</a>)}
      </nav>
      <button className="burger" aria-label={open ? 'Fechar menu' : 'Abrir menu'} onClick={() => setOpen(!open)}>
        {open ? <X /> : <Menu />}
      </button>
    </header>
  )
}

function Hero() {
  return (
    <section id="inicio" className="hero">
      <div className="hero-text">
        <p className="eyebrow">Saúde e beleza capilar</p>
        <h1>BELOS <em>FIOS</em></h1>
        <h2>A beleza dos seus cabelos começa com o cuidado certo.</h2>
        <p>Realinhamento, tratamento, hidratação e botox capilar com atendimento personalizado e atenção a cada detalhe.</p>
        <Btn href={wa('Olá! Gostaria de agendar meu atendimento no BELOS FIOS.')}><MessageCircle size={18} /> Agendar meu atendimento</Btn>
      </div>
      <div className="hero-photo"><img src="/sara.jpg" alt="Sara Natane, responsável pelo BELOS FIOS" fetchpriority="high" /></div>
    </section>
  )
}

function About() {
  return (
    <section id="sobre" className="section about">
      <Reveal className="about-photo"><img src="/sara-sobre.jpg" alt="Sara Natane" loading="lazy" /></Reveal>
      <Reveal className="about-text">
        <p className="eyebrow">Sobre a profissional</p>
        <h3>Sara Natane</h3>
        <p>Olá, sou Sara Natane, profissional da área de beleza capilar e responsável pelo BELOS FIOS. Com mais de 4 anos de experiência, formação técnica e capacitação profissional, trabalho com dedicação, cuidado e atenção a cada detalhe para valorizar a beleza natural dos seus cabelos. Meu objetivo é oferecer tratamentos personalizados, respeitando as necessidades de cada cliente e proporcionando resultados incríveis.</p>
        <Btn href={wa('Olá, Sara! Gostaria de conversar sobre o cuidado dos meus cabelos.')}><MessageCircle size={18} /> Conversar com Sara</Btn>
      </Reveal>
    </section>
  )
}

function Services() {
  return (
    <section id="servicos" className="section">
      <Reveal><p className="eyebrow center">O que fazemos</p><h3 className="center">Nossos serviços</h3></Reveal>
      <div className="cards">
        {services.map((s) => {
          const Icon = icons[s.icon]
          return (
            <Reveal key={s.name} className="card">
              <Icon size={30} strokeWidth={1.3} />
              <h4>{s.name}</h4>
              <p>{s.text}</p>
              <Btn variant="ghost" href={wa(`Olá! Gostaria de solicitar um orçamento de ${s.name} no BELOS FIOS.`)}>Solicitar orçamento</Btn>
            </Reveal>
          )
        })}
      </div>
    </section>
  )
}

function BeforeAfter({ item }) {
  const [pos, setPos] = useState(50)
  return (
    <div className="ba">
      <img src={item.after} alt={`${item.title} – depois`} loading="lazy" />
      <img className="ba-before" src={item.before} alt={`${item.title} – antes`} loading="lazy" style={{ clipPath: `inset(0 ${100 - pos}% 0 0)` }} />
      <span className="tag l">Antes</span><span className="tag r">Depois</span>
      <div className="ba-line" style={{ left: `${pos}%` }}><i /></div>
      <input type="range" min="0" max="100" value={pos} aria-label="Comparar antes e depois" onChange={(e) => setPos(+e.target.value)} />
    </div>
  )
}

function Gallery() {
  const [open, setOpen] = useState(null)
  useEffect(() => {
    const k = (e) => e.key === 'Escape' && setOpen(null)
    window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k)
  }, [])
  return (
    <section id="resultados" className="section">
      <Reveal><p className="eyebrow center">Resultados reais</p><h3 className="center">Antes e depois</h3></Reveal>
      {results.length === 0 ? (
        <Reveal className="empty"><p>Acompanhe os resultados das nossas clientes no Instagram.</p><Btn href={INSTAGRAM_URL}><Instagram size={18} /> Ver no Instagram</Btn></Reveal>
      ) : (
        <div className="gallery">
          {results.map((r, i) => (
            <Reveal key={i} className="g-item">
              {r.type === 'video'
                ? <video controls playsInline preload="metadata" poster={r.poster} src={r.src} />
                : <><BeforeAfter item={r} /><button className="zoom" onClick={() => setOpen(r)}>Ampliar</button></>}
              <p>{r.title}</p>
            </Reveal>
          ))}
        </div>
      )}
      {open && (
        <div className="lightbox" onClick={() => setOpen(null)}>
          <button aria-label="Fechar" onClick={() => setOpen(null)}><X /></button>
          <div onClick={(e) => e.stopPropagation()}><BeforeAfter item={open} /></div>
        </div>
      )}
    </section>
  )
}

function Promo() {
  const [show, setShow] = useState(true)
  if (!show) return null
  return (
    <div className="promo">
      <button aria-label="Fechar promoção" onClick={() => setShow(false)}><X size={14} /></button>
      <a href={wa('Olá! Quero saber mais sobre a promoção: indique uma cliente e ganhe 30% de desconto.')} target="_blank" rel="noopener noreferrer">
        <Gift size={18} /><strong>INDIQUE UMA CLIENTE E GANHE 30% DE DESCONTO!</strong>
        <small>Indique uma amiga e ganhe 30% de desconto no seu próximo procedimento, conforme as condições da promoção.</small>
      </a>
    </div>
  )
}

function Contact() {
  return (
    <section id="contato" className="section contact">
      <Reveal>
        <p className="eyebrow center">Contato</p><h3 className="center">Vamos cuidar dos seus fios</h3>
        <ul>
          <li><MessageCircle size={20} /> WhatsApp: {PHONE_LABEL}</li>
          <li><Instagram size={20} /> Instagram: {INSTAGRAM}</li>
          <li><MapPin size={20} /> Valparaíso de Goiás – GO</li>
        </ul>
        <div className="row">
          <Btn href={wa('Olá! Gostaria de agendar um atendimento no BELOS FIOS.')}><MessageCircle size={18} /> WhatsApp</Btn>
          <Btn variant="ghost" href={INSTAGRAM_URL}><Instagram size={18} /> Instagram</Btn>
        </div>
      </Reveal>
    </section>
  )
}

function Footer() {
  return (
    <footer className="footer">
      <div className="logo">BELOS <span>FIOS</span></div>
      <p>Sara Natane</p>
      <p><a href={INSTAGRAM_URL} target="_blank" rel="noopener noreferrer">{INSTAGRAM}</a> · <a href={wa('Olá! Vim pelo site do BELOS FIOS.')} target="_blank" rel="noopener noreferrer">{PHONE_LABEL}</a></p>
      <p>Valparaíso de Goiás – GO</p>
      <em>Sua beleza, nosso cuidado.</em>
    </footer>
  )
}

export default function App() {
  return (
    <>
      <Header /><main><Hero /><About /><Services /><Gallery /><Contact /></main><Footer />
      <Promo />
      <a className="fab" aria-label="Falar no WhatsApp" href={wa('Olá! Vim pelo site do BELOS FIOS.')} target="_blank" rel="noopener noreferrer"><MessageCircle size={26} /></a>
    </>
  )
}
