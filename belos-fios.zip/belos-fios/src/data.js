// Central de conteúdo: edite aqui para atualizar o site.
export const PHONE = '5561991374571'
export const PHONE_LABEL = '(61) 99137-4571'
export const INSTAGRAM = '@belosfios_saranatane'
export const INSTAGRAM_URL = 'https://www.instagram.com/belosfios_saranatane/'
export const wa = (msg) => `https://wa.me/${PHONE}?text=${encodeURIComponent(msg)}`

export const services = [
  { name: 'Realinhamento capilar', icon: 'Sparkles', text: 'Fios mais alinhados, macios e com aspecto disciplinado, em um procedimento pensado para o seu tipo de cabelo.' },
  { name: 'Tratamento capilar', icon: 'Heart', text: 'Cuidado personalizado para devolver vitalidade e equilíbrio aos fios, de acordo com a necessidade de cada cliente.' },
  { name: 'Hidratação', icon: 'Droplets', text: 'Reposição de água e nutrientes para cabelos com mais maciez, brilho e toque sedoso.' },
  { name: 'Botox capilar', icon: 'Gem', text: 'Tratamento que ajuda a reduzir o frizz e a dar mais brilho e leveza, respeitando a saúde dos fios.' },
]

// GALERIA — adicione os arquivos em /public/results e liste aqui.
// Antes e depois: { type: 'slider', title: 'Realinhamento', before: '/results/antes1.jpg', after: '/results/depois1.jpg' }
// Vídeo:          { type: 'video',  title: 'Resultado',     src: '/results/video1.mp4', poster: '/results/video1.jpg' }
export const results = []
